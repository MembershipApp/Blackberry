

function successCheckIn(){
	$('#CheckinSuccessful').replaceWith('<div id="btnCheckIn" ><a onclick="onCheckInClick()">Check In Here</a></div>');
}