package com.infostretch.isosbb.models;

import net.rim.device.api.util.Persistable;
/***
 * Model class to hold user name 
 * @author Amit Gupta
 *
 */
public class Username implements Persistable{

	private String username = "";

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}
}
